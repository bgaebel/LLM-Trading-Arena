@echo off
cd /d "%~dp0"
python main.py serve --demo
pause
