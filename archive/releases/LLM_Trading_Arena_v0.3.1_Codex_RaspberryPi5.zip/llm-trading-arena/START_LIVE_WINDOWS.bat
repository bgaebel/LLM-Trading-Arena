@echo off
cd /d "%~dp0"
python main.py start
pause
